// scheduler.cc 
//	Routines to choose the next thread to run, and to dispatch to
//	that thread.
//
// 	These routines assume that interrupts are already disabled.
//	If interrupts are disabled, we can assume mutual exclusion
//	(since we are on a uniprocessor).
//
// 	NOTE: We can't use Locks to provide mutual exclusion here, since
// 	if we needed to wait for a lock, and the lock was busy, we would 
//	end up calling FindNextToRun(), and that would put us in an 
//	infinite loop.
//
// 	Very simple implementation -- no priorities, straight FIFO.
//	Might need to be improved in later assignments.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "debug.h"
#include "scheduler.h"
#include "main.h"

//----------------------------------------------------------------------
// Scheduler::Scheduler
// 	Initialize the list of ready but not running threads.
//	Initially, no ready threads.
//----------------------------------------------------------------------

Scheduler::Scheduler()
{
//	schedulerType = type;
	readyList = new List<Thread *>; 
	toBeDestroyed = NULL;
} 

//----------------------------------------------------------------------
// Scheduler::~Scheduler
// 	De-allocate the list of ready threads.
//----------------------------------------------------------------------

Scheduler::~Scheduler()
{ 
    delete readyList; 
} 

//----------------------------------------------------------------------
// Scheduler::ReadyToRun
// 	Mark a thread as ready, but not running.
//	Put it on the ready list, for later scheduling onto the CPU.
//
//	"thread" is the thread to be put on the ready list.
//----------------------------------------------------------------------

void
Scheduler::ReadyToRun (Thread *thread)
{
    DEBUG('tmm', "Putting thread %s  on ready list.\n ", thread->getName());
    
    thread->setStatus(READY);

    switch (policy) {
    case RR: // Round Robin
      #ifdef CHANGE
      readyList->Append(thread);
      break;
      #else
      #endif
    case SJF: //Shortest Job First
      #ifdef CHANGE
      readyList->SortedInsert(thread, thread->getTimeLeft());
      break;
      #else
      #endif
    case Priority:
      #ifdef CHANGE
      readyList->SortedInsert(thread, 20 - thread->getPriority());
      break;
      #else
      #endif
    case SRTF: //Shortest Remaining Time First
      #ifdef CHANGE
      readyList->SortedInsert(thread, thread->getTimeLeft());
      break;
      #else
      #endif
    default: //FCFS
      readyList->Append(thread);
      break;
    }
}

//----------------------------------------------------------------------
// Scheduler::FindNextToRun
// 	Return the next thread to be scheduled onto the CPU.
//	If there are no ready threads, return NULL.
// Side effect:
//	Thread is removed from the ready list.
//----------------------------------------------------------------------

Thread *
Scheduler::FindNextToRun ()
{
    ASSERT(kernel->interrupt->getLevel() == IntOff);

    if (readyList->IsEmpty()) {
	return NULL;
    } else {
    	return readyList->RemoveFront();
    }
}

//----------------------------------------------------------------------
// Scheduler::Run
// 	Dispatch the CPU to nextThread.  Save the state of the old thread,
//	and load the state of the new thread, by calling the machine
//	dependent context switch routine, SWITCH.
//
//      Note: we assume the state of the previously running thread has
//	already been changed from running to blocked or ready (depending).
// Side effect:
//	The global variable kernel->currentThread becomes nextThread.
//
//	"nextThread" is the thread to be put into the CPU.
//	"finishing" is set if the current thread is to be deleted
//		once we're no longer running on its stack
//		(when the next thread starts running)
//----------------------------------------------------------------------

void
Scheduler::Run (Thread *nextThread)
{
    Thread *oldThread = kernel->currentThread;
 
//	cout << "Current Thread" <<oldThread->getName() << "    Next Thread"<<nextThread->getName()<<endl;
    
#ifdef USER_PROGRAM			// ignore until running user programs 
    if (currentThread->space != NULL) {	// if this thread is a user program,
        currentThread->SaveUserState(); // save the user's CPU registers
	currentThread->space->SaveState();
    }
#endif
    
    oldThread->CheckOverflow();		    // check if the old thread
					    // had an undetected stack overflow

    kernel->currentThread = nextThread;  // switch to the next thread
    currentThread->setStatus(RUNNING);      // nextThread is now running
    
    DEBUG('tmm', "Switching from \"%s\" to thread \"%s\" \n ", oldThread->getName(), nextThread->getName());

    #ifdef CHANGE
    if(policy == RR) {
      if (currentThread->getTimeLeft() >= (currentThread->quantumTime/10 -1) {
	  interrupt->Schedule(SchedInterruptHandler, (int)this, currentThread->quantumTime, TimerInt);
      }
    }
    #else
    #endif
    
    // This is a machine-dependent assembly language routine defined 
    // in switch.s.  You may have to think
    // a bit to figure out what happens after this, both from the point
    // of view of the thread and from the perspective of the "outside world".

    SWITCH(oldThread, nextThread);

    // we're back, running oldThread
      
    // interrupts are off when we return from switch!

    DEBUG('tmm', "Now in thread \"%s\" \n" << currentThread->getName());

    if(threadTobeDestroyed != NULL) {
      delete threadToBeDestroyed;
      threadToBeDestroyed = NULL;
    }
    
#ifdef USER_PROGRAM
    if (currentThread->space != NULL) {	    // if there is an address space
        currentThread->RestoreUserState();     // to restore, do it.
	currentThread->space->RestoreState();
    }
#endif
}

//----------------------------------------------------------------------
// Scheduler::CheckToBeDestroyed
// 	If the old thread gave up the processor because it was finishing,
// 	we need to delete its carcass.  Note we cannot delete the thread
// 	before now (for example, in Thread::Finish()), because up to this
// 	point, we were still running on the old thread's stack!
//----------------------------------------------------------------------

void
Scheduler::CheckToBeDestroyed()
{
    if (toBeDestroyed != NULL) {
        delete toBeDestroyed;
	toBeDestroyed = NULL;
    }
}
 
//----------------------------------------------------------------------
// Scheduler::Print
// 	Print the scheduler state -- in other words, the contents of
//	the ready list.  For debugging.
//----------------------------------------------------------------------
void
Scheduler::Print()
{
    cout << "Ready list contents:\n";
    readyList->Apply(ThreadPrint);
}

bool
Scheduler::ShouldISwitch (Thread* oldThread, Thread* newThread) {
  bool answer;

  switch (policy) {
  case RR: // Round Robin
    #ifdef CHANGE
    answer = false;
    break;
    #else
    #endif
  case SJF: //Shortest Job First
    #ifdef CHANGE
    answer = false;
    break;
    #else
    #endif
  case Priority:
    #ifdef CHANGE
    if(oldThread->getPriority() < newThread->getPriority()) { answer = true;}
    break;
    #else
    #endif
  case SRTF: //Shortest Remaining Time First
    #ifdef CHANGE
    if(oldThread->getTimeLeft() < newThread->getTimeLeft()) { answer = true;}
    break;
    #else
    #endif
  default: //FCFS
    answer = false;
    break;
  }

  return answer;
}

void
Scheduler::Suspend(Thread * thread) {
  List<Thread*> *tmp = new List<Thread*>();
  Thread *tmm;

  // Remove thread from ready list
  while(!readyList->IsEmpty()) {
    tmm = readyList->Remove();
    if(tmm == thread) {
      break;
    } else {
      tmp->Prepend(tmm);
    }
  }

  // Add suspended thread to suspended list
  if(tmm == thread) {
    tmm->setStatus(SUSPENDED);
    suspendedList->Append(tmm);
  }

  // All threads before the suspended thread in ready list are in
  // suspended list. Add them back to ready list
  while(!tmp->IsEmpty()) {
    tmm = tmp->Remove();
    readyList->Prepend(tmm);
  }
}

void
Scheduler::Resumed(Thread * thread) {
  List<Thread*> *tmp = new List<Thread*>();
  Thread *tmm;

  // Remove thread from suspended list
  while(!suspendedList->IsEmpty()) {
    tmm = suspendedList->Remove();
    if(tmm == thread) {
      break;
    } else {
      tmp->Prepend(tmm);
    }
  }

  // Add resumed thread to ready list
  if(tmm == thread) {
    tmm->setStatus(READY);
    readyList->Append(tmm);
  }

  // All threads before the suspended thread in ready list are in
  // suspended list. Add them back to ready list
  while(!tmp->IsEmpty()) {
    tmm = tmp->Remove();
    suspendedList->Prepend(tmm);
  }
}

void
Scheduler::setSchedType(SchedulerType Sched) {
  SchedulerType oldPolicy = policy;
  policy  = Sched;
  if(oldPolicy == policy) return;
  switch(policy) {
  case RR:
    cout << "Round Robin Scheduling" << endl;
    break;
  case SJF:
    cout << "Shortest Job First Scheduling" << endl;
    break;
  case Priority:
    cout << "Priority Scheduling" << endl;
    break;
  case SRTF:
    cout << "Shortest Remaining Time First Scheduling" << endl;
    break;
  default:
    cout << "First Come First Serve Scheduling" << endl;
    break;
  }
}
