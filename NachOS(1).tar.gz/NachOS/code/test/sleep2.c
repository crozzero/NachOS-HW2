#include "syscall.h"

main() {
  int i;
  for(i = 0; i < 25; i++) {
    Sleep(100000);
    PrintInt(1111);
  }
  return 0;
}
